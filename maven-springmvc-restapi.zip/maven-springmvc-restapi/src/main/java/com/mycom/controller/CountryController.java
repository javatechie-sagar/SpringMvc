package com.mycom.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mycom.bean.Country;
import com.mycom.service.CountryService;

@RestController
public class CountryController {
	CountryService countryService = new CountryService();

	@RequestMapping(value = "/countries", method = RequestMethod.GET, 
			headers = "Accept=application/json")
//	@GetMapping( "/countries")
	public List getCountries() {
		List listOfCountries = countryService.getAllCountries();
		return listOfCountries;
	}
	
	@RequestMapping(value = "/country/{id}", method = RequestMethod.GET, 
			headers = "Accept=application/json")
	public Country getCountryById(@PathVariable int id) {
		return countryService.getCountry(id);
	}
	
	
	

	@RequestMapping(value = "/countries", method = RequestMethod.POST, 
			headers = "Accept=application/json")
	public Country addCountry(@RequestBody Country country) {
		return countryService.addCountry(country);
	}
	
	
	@RequestMapping(value = "/countries", method = RequestMethod.PUT, 
			headers = "Accept=application/json")
	public Country updateCountry(@RequestBody Country country) {
		return countryService.updateCountry(country);

	}
	
	@RequestMapping(value = "/country/{id}", method = RequestMethod.DELETE,
			headers = "Accept=application/json")
	public void deleteCountry(@PathVariable("id") int id) {
		countryService.deleteCountry(id);

	}

}

//	// Create country list
//	// Utiliy method to create country list.
//	public List<Country> createCountryList() {
//		Country india = new Country(1, "India");
//		Country us = new Country(4, "US");
//		Country uk = new Country(3, "UK");
//		Country singapore = new Country(2, "Singapore");
//		Country france = new Country(5, "France");
//		List<Country> countryList = new ArrayList<Country>();
//		countryList.add(india);
//		countryList.add(us);
//		countryList.add(uk);
//		countryList.add(singapore);
//		countryList.add(france);
//		return countryList;
//	}
//	// -------------
//
//	@RequestMapping(value = "/countries", method = RequestMethod.GET, headers = "Accept=application/json")
//	public List<Country> getCountries() {
//		List<Country> countryList = new ArrayList<Country>();
//		countryList = createCountryList();
//		return countryList;
//	}
//
//	@RequestMapping(value = "/country/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
//	
//	public Country getCountryById(@PathVariable int id) {
//		List<Country> countryList = new ArrayList<Country>();
//		countryList = createCountryList();
//
//		for (Country country : countryList) {
//			if (country.getId() == id)
//				return country;
//		}
//
//		return null;
//	}

//	// Delete a country
//	@RequestMapping(value = "/delcountry/{id}", method = RequestMethod.DELETE, headers = "Accept=application/json")
//	public void deleteCountryById(@PathVariable int id) {
//
//		List<Country> countryList = new ArrayList<Country>();
//		countryList = createCountryList();
//		System.out.println(countryList.size());
//		for (int index=0; index<countryList.size();index++) {
//			if ( countryList.get(index).getId() == id) {
//				countryList.remove(index); 
//				System.out.println("Country Deleted!");
//				//return null;
//			}
//		}
//		
//	}

//}
