package com.mycom.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ProductController {
	@RequestMapping("/product")
	public ModelAndView login(HttpServletRequest request, HttpServletResponse response) {
		String productName = request.getParameter("productName");
		String productBrand= request.getParameter("productBrand");
		String message;
			message = "You have selected " + productName + " of " + productBrand;
			return new ModelAndView("welcome", "message", message);

	}
}
