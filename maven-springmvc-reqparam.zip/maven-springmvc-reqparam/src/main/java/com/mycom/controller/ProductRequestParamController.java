package com.mycom.controller;

import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ProductRequestParamController {
	@RequestMapping("/productrqpm")

	public ModelAndView login(@RequestParam("productName") String productName,
			@RequestParam("productBrand") String productBrand) {
		System.out.println(productName);
		if(productName.equals("")|| productBrand.equals("")) {
			String errorMsg;
			errorMsg = "You have not entered product details";
			return new ModelAndView("errorPage","errorMsg",errorMsg);
		}
		String message;
		message = "You have selected " + productName + " of " + productBrand;
		return new ModelAndView("welcome", "message", message);

	}
}
